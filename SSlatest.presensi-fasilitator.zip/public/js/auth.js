import { auth, db } from "./firebase-init.js"
import { signInWithEmailAndPassword, onAuthStateChanged } from "https://www.gstatic.com/firebasejs/10.7.0/firebase-auth.js"
import { doc, getDoc, updateDoc } from "https://www.gstatic.com/firebasejs/10.7.0/firebase-firestore.js"

// === UTILITY: MEMBUAT DEVICE ID ACAK BARU UNTUK BROWSER HP ===
function generateDeviceID() {
    return 'DEV-' + Math.random().toString(36).substring(2, 15) + Date.now().toString(36);
}

// === FITUR TOGGLE PASSWORD & DETEKSI ENTER ===
window.togglePassword = function() {
    const passwordInput = document.getElementById("password");
    const toggleBtn = document.getElementById("toggleBtn");
    
    if (passwordInput.type === "password") {
        passwordInput.type = "text";
        toggleBtn.textContent = "🙈"; // Icon mata tertutup
    } else {
        passwordInput.type = "password";
        toggleBtn.textContent = "👁️"; // Icon mata terbuka
    }
};

document.addEventListener('DOMContentLoaded', () => {
    const emailInput = document.getElementById("email");
    const passwordInput = document.getElementById("password");
    
    const handleEnter = (event) => {
        if (event.key === 'Enter') {
            event.preventDefault(); // Mencegah form tersubmit secara default
            window.login();
        }
    };
    
    if (emailInput) emailInput.addEventListener('keypress', handleEnter);
    if (passwordInput) passwordInput.addEventListener('keypress', handleEnter);
});
// =============================================

// Fungsi Login Utama
window.login = async function() {
    const email = document.getElementById("email").value.trim()
    const password = document.getElementById("password").value
    const loading = document.getElementById("loading")
    
    if (!email || !password) {
        alert("Email dan password harus diisi!")
        return
    }
    
    try {
        loading.style.display = "flex"
        console.log("🔑 Mencoba login dengan email:", email)
        
        const userCredential = await signInWithEmailAndPassword(auth, email, password)
        const user = userCredential.user
        
        console.log("✅ Login sukses, UID:", user.uid)
        
        // Ambil data user dari Firestore
        const userDocRef = doc(db, "users", user.uid);
        const userDoc = await getDoc(userDocRef)
        
        if (userDoc.exists()) {
            const userData = userDoc.data()
            console.log("📋 Data user:", userData)
            console.log("📋 Role user:", userData.role) // Debug role
            
            // Validasi role dasar
            if (!userData.role) {
                console.error("User tidak memiliki role!")
                alert("Error: Data user tidak lengkap (role tidak ada). Hubungi admin.")
                await auth.signOut();
                return
            }
            
            // ----------------------------------------------------
            // SYSTEM VALIDASI: DEVICE LOCK (KHUSUS FASILITATOR)
            // ----------------------------------------------------
            if (userData.role !== "admin" && userData.role !== "koordinator") {
                // Ambil Device ID yang saat ini nempel di browser HP/PC
                let currentDeviceID = localStorage.getItem("my_device_id");
                
                // Ambil data kunci perangkat yang terdaftar di akun database fasilitator ini
                const registeredDeviceID = userData.deviceId || null;

                // KONDISI A: Akun baru pertama kali login di HP (Database kosong)
                if (!registeredDeviceID) {
                    // Jika di browser HP ini belum memiliki identitas acak, buatkan baru
                    if (!currentDeviceID) {
                        currentDeviceID = generateDeviceID();
                        localStorage.setItem("my_device_id", currentDeviceID);
                    }

                    // Kunci dan daftarkan ID perangkat ini ke akun Firestore fasilitator
                    await updateDoc(userDocRef, {
                        deviceId: currentDeviceID
                    });

                    alert("Perangkat Terdaftar! Akun Anda kini sukses dikunci pada perangkat ini.");
                } 
                // KONDISI B: Akun sudah terikat ke salah satu perangkat
                else {
                    // Jika ID browser HP yang dipakai tidak sama dengan database akun
                    if (currentDeviceID !== registeredDeviceID) {
                        alert("Gagal Masuk! Akun Anda telah terikat pada HP lain.\n\nSilakan hubungi Koordinator Lapangan Anda untuk melakukan reset perangkat.");
                        
                        // Putus sesi paksa auth firebase karena perangkat tidak sah
                        await auth.signOut();
                        loading.style.display = "none";
                        return; // Stop login
                    }
                }
            }
            // ----------------------------------------------------
            
            // Simpan data sesi ke localStorage jika lolos validasi device
            localStorage.setItem("isLogin", "true");
            localStorage.setItem("userRole", userData.role);
            localStorage.setItem("userData", JSON.stringify({
                uid: user.uid,
                nama: userData.nama || user.email.split('@')[0],
                email: userData.email,
                role: userData.role,
                kelurahan: userData.kelurahan || null
            }))
            
            console.log("💾 Data tersimpan di localStorage, role:", userData.role)
            
            // ===== REDIRECT BERDASARKAN ROLE =====
            if (userData.role === "admin") {
                console.log("👉 Redirect ke admin.html")
                window.location.href = "admin.html"
            } 
            else if (userData.role === "koordinator") {
                console.log("👉 Redirect ke koordinator-dashboard.html")
                window.location.href = "koordinator-dashboard.html"
            } 
            else {
                console.log("👉 Redirect ke dashboard.html")
                window.location.href = "dashboard.html"
            }
        } else {
            console.error("User tidak ditemukan di Firestore. UID:", user.uid)
            alert("Data user tidak ditemukan! Hubungi admin.")
            await auth.signOut()
        }
        
    } catch (error) {
        console.error("❌ Login error:", error)
        
        let errorMessage = "Login gagal! "
        switch (error.code) {
            case 'auth/invalid-credential':
            case 'auth/user-not-found':
            case 'auth/wrong-password':
                errorMessage += "Email atau password salah."
                break
            case 'auth/too-many-requests':
                errorMessage += "Terlalu banyak percobaan. Coba lagi nanti."
                break
            default:
                errorMessage += error.message
        }
        
        alert(errorMessage)
        
    } finally {
        loading.style.display = "none"
    }
}

// Fungsi Reset Password via Email
window.resetPassword = async function(email) {
    if (!email) {
        email = document.getElementById('email').value;
        if (!email) {
            alert('Masukkan email!');
            return;
        }
    }
    
    const loading = document.getElementById("loading");
    
    try {
        loading.style.display = "flex";
        console.log("🔑 Mengirim reset password ke:", email);
        
        const { sendPasswordResetEmail } = await import("https://www.gstatic.com/firebasejs/10.7.0/firebase-auth.js");
        await sendPasswordResetEmail(auth, email);
        
        alert(`✅ Email reset password telah dikirim ke ${email}\n\nCek inbox/spam folder Anda.`);
        
    } catch (error) {
        console.error("❌ Error reset password:", error);
        
        let errorMessage = "Gagal kirim email: ";
        switch (error.code) {
            case 'auth/user-not-found':
                errorMessage += "Email tidak terdaftar";
                break;
            case 'auth/too-many-requests':
                errorMessage += "Terlalu banyak permintaan. Coba lagi nanti";
                break;
            default:
                errorMessage += error.message;
        }
        
        alert(errorMessage);
        
    } finally {
        loading.style.display = "none";
    }
}

// Auto redirect jika sudah login / cookies aktif
onAuthStateChanged(auth, async (user) => {
    const currentPage = window.location.pathname.split('/').pop() || 'index.html'
    
    if (user) {
        if (currentPage === 'index.html' || currentPage === '') {
            const userDocRef = doc(db, "users", user.uid);
            const userDoc = await getDoc(userDocRef)
            if (userDoc.exists()) {
                const userData = userDoc.data();
                const role = userData.role;
                
                // PROTEKSI TAMBAHAN PADA AUTO REDIRECT UNTUK FASILITATOR
                if (role !== "admin" && role !== "koordinator") {
                    let currentDeviceID = localStorage.getItem("my_device_id");
                    if (userData.deviceId && currentDeviceID !== userData.deviceId) {
                        await auth.signOut();
                        return;
                    }
                }
                
                console.log("🔄 Auto redirect, role:", role)
                localStorage.setItem("isLogin", "true");
                localStorage.setItem("userRole", role);
                
                if (role === 'admin') {
                    window.location.href = 'admin.html'
                } else if (role === 'koordinator') {
                    window.location.href = 'koordinator-dashboard.html'
                } else {
                    window.location.href = 'dashboard.html'
                }
            }
        }
    } else {
        if (currentPage !== 'index.html' && currentPage !== '') {
            window.location.href = 'index.html'
        }
    }
});