import { initializeApp } from "https://www.gstatic.com/firebasejs/10.7.0/firebase-app.js"
import { getAuth } from "https://www.gstatic.com/firebasejs/10.7.0/firebase-auth.js"
import { getFirestore } from "https://www.gstatic.com/firebasejs/10.7.0/firebase-firestore.js"

// KONFIGURASI FIREBASE - GANTI DENGAN PUNYA ANDA
const firebaseConfig = {
  apiKey: "AIzaSyAceQFkuOtCVEwc_a-l_fDIMOeOh4GzTsc",
  authDomain: "absensifasilitator.firebaseapp.com",
  projectId: "absensifasilitator",
  storageBucket: "absensifasilitator.firebasestorage.app",
  messagingSenderId: "329902795520",
  appId: "1:329902795520:web:2a2ba3e841a1940623e1e5"
};

// Inisialisasi Firebase
const app = initializeApp(firebaseConfig)
const auth = getAuth(app)
const db = getFirestore(app)

console.log("✅ Firebase initialized")

export { auth, db }