import { db } from "./firebase-init.js"
import { doc, getDoc, updateDoc, collection, query, where } from "https://www.gstatic.com/firebasejs/10.7.0/firebase-firestore.js"

// Generate unique device ID
export function generateDeviceId() {
    try {
        const navigatorInfo = navigator.userAgent || 'unknown'
        let screenWidth = 'unknown'
        let screenHeight = 'unknown'
        try {
            screenWidth = window.screen.width
            screenHeight = window.screen.height
        } catch (e) {
            console.warn('Tidak bisa akses screen:', e)
        }
        
        const timezone = Intl.DateTimeFormat().resolvedOptions().timeZone || 'unknown'
        const language = navigator.language || 'unknown'
        const timestamp = Date.now()
        
        const deviceString = `${navigatorInfo}|${screenWidth}x${screenHeight}|${timezone}|${language}|${timestamp}`
        
        let hash = 0
        for (let i = 0; i < deviceString.length; i++) {
            const char = deviceString.charCodeAt(i)
            hash = ((hash << 5) - hash) + char
            hash = hash & hash
        }
        
        return 'DEV_' + Math.abs(hash).toString(36).toUpperCase()
        
    } catch (error) {
        return 'DEV_' + Date.now().toString(36).toUpperCase() + '_' + Math.random().toString(36).substring(2, 7)
    }
}

// Helper untuk mengekstrak tanggal dalam zona waktu WIB (UTC+7)
// Ini mencegah user memanipulasi jam lokal di HP mereka
function getWIBDateComponents(dateObj) {
    // Tambahkan 7 jam (7 * 60 * 60 * 1000 milidetik) ke waktu UTC absolut
    const wibTime = new Date(dateObj.getTime() + (7 * 60 * 60 * 1000));
    return {
        year: wibTime.getUTCFullYear(),
        month: wibTime.getUTCMonth(),
        date: wibTime.getUTCDate()
    };
}

// Validasi device dengan AUTO-RESET setiap 00:00 WIB
export async function validateDevice(uid) {
    try {
        console.log("🔍 Validating device for UID:", uid)
        
        if (!uid || uid === 'undefined') {
            console.log("UID tidak valid, skip device check")
            return true
        }
        
        let deviceId = localStorage.getItem('deviceId')
        
        if (!deviceId) {
            deviceId = generateDeviceId()
            localStorage.setItem('deviceId', deviceId)
        }
        
        // CARI USER - Coba berbagai cara
        let userRef = null
        let userData = null
        
        // Cara 1: Coba dengan document ID = uid
        try {
            const docRef = doc(db, "users", uid)
            const docSnap = await getDoc(docRef)
            if (docSnap.exists()) {
                userRef = docRef
                userData = docSnap.data()
                console.log("User ditemukan dengan document ID = uid")
            }
        } catch (e) {}
        
        // Cara 2: Cari berdasarkan field uid
        if (!userData) {
            const q = query(collection(db, "users"), where("uid", "==", uid))
            const querySnap = await getDocs(q)
            if (!querySnap.empty) {
                userRef = doc(db, "users", querySnap.docs[0].id)
                userData = querySnap.docs[0].data()
                console.log("User ditemukan dengan field uid")
            }
        }
        
        if (!userData) {
            console.log("User tidak ditemukan, skip device check")
            return true
        }
        
        console.log("User role:", userData.role)
        
        // ADMIN & KOORDINATOR BEBAS DEVICE
        if (userData.role === 'admin' || userData.role === 'koordinator') {
            console.log("👑 Admin/Koordinator - bebas device")
            await updateDoc(userRef, { lastSeen: new Date() })
            return true
        }
        
        // ========== USER BIASA DENGAN RESET 00:00 WIB ==========
        console.log("👤 User biasa - validasi device harian (WIB)")
        
        // Jika user belum punya deviceId, simpan yang sekarang
        if (!userData.deviceId) {
            console.log("User has no deviceId, saving current")
            await updateDoc(userRef, {
                deviceId: deviceId,
                lastSeen: new Date()
            })
            return true
        }
        
        // Cek kecocokan device
        if (userData.deviceId !== deviceId) {
            console.log("❌ Device mismatch! Stored:", userData.deviceId, "Current:", deviceId)
            
            // CEK TANGGAL TERAKHIR LOGIN (Absolut)
            const lastSeen = userData.lastSeen?.seconds 
                ? new Date(userData.lastSeen.seconds * 1000) 
                : new Date(0);
            
            const now = new Date();
            
            // Konversi ke komponen kalender WIB
            const lastSeenWIB = getWIBDateComponents(lastSeen);
            const nowWIB = getWIBDateComponents(now);
            
            // Evaluasi apakah hari kalender WIB sudah berganti
            const isNewDayWIB = 
                lastSeenWIB.year !== nowWIB.year ||
                lastSeenWIB.month !== nowWIB.month ||
                lastSeenWIB.date !== nowWIB.date;
            
            console.log(`⏱️ Terakhir login (UTC): ${lastSeen.toISOString()}`);
            console.log(`⏱️ Waktu sekarang (UTC): ${now.toISOString()}`);
            
            // Jika sudah berganti hari (00:00 WIB sudah terlewati)
            if (isNewDayWIB) {
                console.log("✅ Ganti hari (00:00 WIB terlewati), reset device otomatis diizinkan");
                await updateDoc(userRef, {
                    deviceId: deviceId,
                    lastSeen: new Date(),
                    lastAutoReset: new Date()
                });
                return true;
            }
            
            // Jika belum ganti hari WIB, block login di device baru ini
            console.log("🚫 User DIBLOKIR - device berbeda di hari yang sama (WIB)");
            return false;
        }
        
        // Device cocok, update lastSeen
        await updateDoc(userRef, { lastSeen: new Date() })
        return true
        
    } catch (error) {
        console.error("Error validate device:", error)
        return true
    }
}

// Reset device user (Manual dari dashboard admin)
export async function resetUserDevice(uid) {
    try {
        console.log("🔄 Resetting device for UID:", uid)
        
        if (!uid || uid === 'undefined') {
            throw new Error("UID tidak valid")
        }
        
        // CARI USER
        let userRef = null
        let userFound = false
        
        // Cara 1: Coba dengan document ID = uid
        try {
            const testRef = doc(db, "users", uid)
            const testDoc = await getDoc(testRef)
            if (testDoc.exists()) {
                userRef = testRef
                userFound = true
                console.log("User ditemukan dengan document ID")
            }
        } catch (e) {}
        
        // Cara 2: Cari berdasarkan field uid
        if (!userFound) {
            const q = query(collection(db, "users"), where("uid", "==", uid))
            const querySnap = await getDocs(q)
            if (!querySnap.empty) {
                userRef = doc(db, "users", querySnap.docs[0].id)
                userFound = true
                console.log("User ditemukan dengan field uid")
            }
        }
        
        if (!userFound) {
            throw new Error("User tidak ditemukan di database")
        }
        
        // Reset device
        await updateDoc(userRef, {
            deviceId: null,
            deviceResetAt: new Date()
        })
        
        return { success: true, message: "Device berhasil direset" }
        
    } catch (error) {
        console.error("Error reset device:", error)
        return { success: false, message: error.message }
    }
}